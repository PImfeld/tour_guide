package com.example.tourguide;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class InformationAdapter extends ArrayAdapter<Information> {

    public InformationAdapter(@NonNull Context context, ArrayList<Information> placeInfo) {
        super(context, 0);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //checks if the existing view is being returned
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        //gets the information at the current location in the list
        Information currentInfo = getItem(position);

        //finds the title text view in list_item.xml
        TextView titleTextView = convertView.findViewById(R.id.title_text_view);
        //gets the title from the current info and sets it on the title text view
        assert currentInfo != null;
        titleTextView.setText(currentInfo.getTitleId());

        //finds the location text view in list_item.xml
        TextView locationTextView = convertView.findViewById(R.id.location_text_view);
        //gets the location from the current info and sets it on the location text view
        locationTextView.setText(currentInfo.getLocationId());

        //finds the image view in the list_item.xml
        ImageView imageView = convertView.findViewById(R.id.image);
        //checks if an image is provided
        if (currentInfo.hasImage()) {
            //gets the image from the current info and sets it on the image view
            imageView.setImageResource(currentInfo.getImageId());
            // Makes sure the view is visible
            imageView.setVisibility(View.VISIBLE);
        } else {
            //hides the image view
            imageView.setVisibility(View.GONE);
        }

        return super.getView(position, convertView, parent);
    }
}
