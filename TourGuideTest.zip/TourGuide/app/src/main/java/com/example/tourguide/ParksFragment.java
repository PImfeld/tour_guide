package com.example.tourguide;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ParksFragment extends Fragment {

    public ParksFragment () {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.info_list, container, false);

        //create a list of information for each place
        final ArrayList<Information> placeInfo = new ArrayList<>();
        placeInfo.add(new Information(R.string.avilas_ranchito, R.string.avilas_address));
        placeInfo.add(new Information(R.string.bruxie, R.string.bruxie_address));
        placeInfo.add(new Information(R.string.gabbis, R.string.gabbis_address));
        placeInfo.add(new Information(R.string.haven_gastropub, R.string.haven_address));
        placeInfo.add(new Information(R.string.the_hobbit, R.string.hobbit_address));
        placeInfo.add(new Information(R.string.kings_fish_house, R.string.kings_fish_house_address));
        placeInfo.add(new Information(R.string.orange_hill_restaurant, R.string.orange_hill_address));
        placeInfo.add(new Information(R.string.rutabegorz, R.string.rutabegorz_address));
        placeInfo.add(new Information(R.string.wise_guys_pizzeria, R.string.Wise_guys_address));
        placeInfo.add(new Information(R.string.zovs_bistro_bakery, R.string.zovs_address));

        //creates an information adapter
        InformationAdapter adapter = new InformationAdapter(getActivity(), placeInfo);

        //finds the list view in the activity
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        //makes the list view use the information adaptor
        listView.setAdapter(adapter);


        return super.onCreateView(inflater, container, savedInstanceState);
    }
}
