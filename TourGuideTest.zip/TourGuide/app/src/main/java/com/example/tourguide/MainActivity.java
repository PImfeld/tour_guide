package com.example.tourguide;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Finds the view pager that allows the user to swipe between fragments
        ViewPager viewPager = findViewById(R.id.viewpager);

        // Creates an adapter that knows which fragment should be shown on each page
        CategoryAdapter adapter = new CategoryAdapter(this, getSupportFragmentManager());

        // Sets the adapter onto the view pager
        viewPager.setAdapter(adapter);

        // Finds the tab layout that shows the tabs
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);

        // Connects the tab layout with the view pager
        tabLayout.setupWithViewPager(viewPager);



    }
}
