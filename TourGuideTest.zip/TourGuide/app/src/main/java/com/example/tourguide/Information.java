package com.example.tourguide;

public class Information {

    //resource id for the title/name
    private int mTitleId;
    //resource id for the location
    private int mLocationId;
    //resource id for the image
    private int mImageId = NO_IMAGE_PROVIDED;
    //Constant value represents no image provided
    private static final int NO_IMAGE_PROVIDED = -1;

    //creates a new information object for categories with only title and location
    public Information(int titleId, int locationId) {
        mTitleId = titleId;
        mLocationId = locationId;
    }

    //crates a new information object for categories with a title, location and image
    public Information(int titleId, int locationId, int imageId) {
        mTitleId = titleId;
        mLocationId = locationId;
        mImageId = imageId;
    }

    //gets the title of the place
    public int getTitleId () {
        return mTitleId;
    }

    //gets the location of the place
    public int getLocationId () {
        return mLocationId;
    }

    //gets the image of the place
    public int getImageId () {
        return mImageId;
    }

    //determines if there is an image for the place
    public boolean hasImage() {
        return mImageId != NO_IMAGE_PROVIDED;
    }
}
